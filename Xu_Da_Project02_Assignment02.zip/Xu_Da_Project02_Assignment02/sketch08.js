let video;
let poseNet;
let poses = [];

let numSegments = 10,
    x = [],
    y = [],
    angle = [],
    segLength = 26,
    targetX,
    targetY;


for (let i = 0; i < numSegments; i++) {
    x[i] = 0;
    y[i] = 0;
    angle[i] = 0;
}



function setup() {
    createCanvas(640, 480);
    video = createCapture(VIDEO);
    video.size(width, height);

    // Create a new poseNet method with a single detection
    poseNet = ml5.poseNet(video, {
        outputStride: 8,
        quantBytes: 4
    }, modelReady);
    // This sets up an event that fills the global variable "poses"
    // with an array every time new poses are detected
    poseNet.on('pose', function (results) {
        poses = results;
    });
    // Hide the video element, and just show the canvas
    //    video.hide();

    strokeWeight(9);
    stroke(255, 100);

    x[x.length - 1] = width / 2; 
    y[x.length - 1] = height; 
}

function modelReady() {
    select('#status').html('Model Loaded');
}

function mousePressed() {
    console.log(JSON.stringify(poses))
}

function draw() {
    background(100);
    // For one pose only (use a for loop for multiple poses!)
    if (poses.length > 0) {
        const pose = poses[0].pose;
        console.log(pose);

        // Create a pink ellipse for the nose
        fill(213, 0, 0);
        const nose = pose.nose;
       
        ellipse(nose.x, nose.y, 20, 20);

        reachSegment(0, nose.x, nose.y);
        for (let i = 1; i < numSegments; i++) {
            reachSegment(i, targetX, targetY);
        }
        for (let j = x.length - 1; j >= 1; j--) {
            positionSegment(j, j - 1);
        }
        for (let k = 0; k < x.length; k++) {
            segment(x[k], y[k], angle[k], (k + 1) * 2);
        }
    }

}

function positionSegment(a, b) {
  x[b] = x[a] + cos(angle[a]) * segLength;
  y[b] = y[a] + sin(angle[a]) * segLength;
}

function reachSegment(i, xin, yin) {
  const dx = xin - x[i];
  const dy = yin - y[i];
  angle[i] = atan2(dy, dx);
  targetX = xin - cos(angle[i]) * segLength;
  targetY = yin - sin(angle[i]) * segLength;
}

function segment(x, y, a, sw) {
  strokeWeight(sw);
  push();
  translate(x, y);
  rotate(a);
  line(0, 0, segLength, 0);
  pop();
}
