
let video;
let poseNet;
let poses = [];

function setup() {
    createCanvas(640, 480);
    video = createCapture(VIDEO);
    video.size(width, height);

    // Create a new poseNet method with a single detection
    poseNet = ml5.poseNet(video, {
        outputStride: 8,
        quantBytes: 4
    }, modelReady);
    // This sets up an event that fills the global variable "poses"
    // with an array every time new poses are detected
    poseNet.on('pose', function (results) {
        poses = results;
    });
    // Hide the video element, and just show the canvas
    video.hide();
    
    img1 = loadImage('images/1.png');
}

function modelReady() {
    select('#status').html('Model Loaded');
}

function mousePressed() {
    console.log(JSON.stringify(poses))
}

function draw() {
    image(video, 0, 0, width, height);
    strokeWeight(2);

//    filter(THRESHOLD, 1);
    
//    image(img1, 0, 0);
    
    // For one pose only (use a for loop for multiple poses!)
    if (poses.length > 0) {
        const pose = poses[0].pose;
        console.log(pose);

        // Create a pink ellipse for the nose
        fill(213, 0, 0);
        const nose = pose.nose;
        ellipse(nose.x+50, nose.y, 70, 70);





        // Create a yellow ellipse for the right eye
        noStroke();
        fill('#313131');
        const rightEye = pose.rightEye;
        ellipse(rightEye.x, rightEye.y, 130, 80);

        noStroke();
        fill('#00ff1d');
        ellipse(rightEye.x, rightEye.y, 28, 28);

        noStroke();
        fill('#000000');
        //        const rightEye = pose.rightEye;
        ellipse(rightEye.x, rightEye.y, 8, 22);


        // Create a yellow ellipse for the right eye

        noStroke();
        fill('#313131');
        const leftEye = pose.leftEye;
        ellipse(leftEye.x + 100, leftEye.y, 130, 80);

        noStroke();
        fill('#00ff1d');
        ellipse(leftEye.x + 100, leftEye.y, 28, 28);

        noStroke();
        fill('#000000');
        //        const rightEye = pose.rightEye;
        ellipse(leftEye.x + 100, leftEye.y, 8, 22);
    }
}
