let video;
let poseNet;
let poses = [];
let x = [],
    y = [],
    segNum = 20,
    segLength = 18;

for (let i = 0; i < segNum; i++) {
    x[i] = 0;
    y[i] = 0;
}


function setup() {
    createCanvas(640, 480);
    video = createCapture(VIDEO);
    video.size(width, height);

    // Create a new poseNet method with a single detection
    poseNet = ml5.poseNet(video, {
        outputStride: 8,
        quantBytes: 4
    }, modelReady);
    // This sets up an event that fills the global variable "poses"
    // with an array every time new poses are detected
    poseNet.on('pose', function (results) {
        poses = results;
    });
    // Hide the video element, and just show the canvas
    //    video.hide();

    strokeWeight(9);
    stroke(255, 100);
}

function modelReady() {
    select('#status').html('Model Loaded');
}

function mousePressed() {
    console.log(JSON.stringify(poses))
}

function draw() {
    //    image(video, 0, 0, width, height);
    //    strokeWeight(2);
    //
    //    filter(THRESHOLD, 1);

    background(100);
    // For one pose only (use a for loop for multiple poses!)
    if (poses.length > 0) {
        const pose = poses[0].pose;
        console.log(pose);

        // Create a pink ellipse for the nose
        fill(213, 0, 0);
        const nose = pose.nose;
        dragSegment(0, nose.x, nose.y);
        for (let i = 0; i < x.length - 1; i++) {
            dragSegment(i + 1, x[i], y[i]);
        }
    }
}

function dragSegment(i, xin, yin) {
    const dx = xin - x[i];
    const dy = yin - y[i];
    const angle = atan2(dy, dx);
    x[i] = xin - cos(angle) * segLength;
    y[i] = yin - sin(angle) * segLength;
    segment(x[i], y[i], angle);
}

function segment(x, y, a) {
    push();
    translate(x, y);
    rotate(a);
    line(0, 0, segLength, 0);
    pop();
}
