let video;
let pose;
let skeleton;
let angle = 0;
let history = [];
let x, y;


function setup() {

    //    frameRate(10);
    createCanvas(640, 480);
    //    noStroke();
    video = createCapture(VIDEO);
    video.size(width, height);

    poseNet = ml5.poseNet(video, modelLoaded);
    poseNet.on('pose', gotPoses)
    video.hide();

    rectMode(CENTER);
    angleMode(DEGREES);

    x = width / 2;
    y = height;

}

function modelLoaded() {
    console.log();
};



function gotPoses(poses) {
    if (poses.length > 0) {
        pose = poses[0].pose;
        skeleton = poses[0].skeleton;
    }

}


function draw() {
    
    background(200);

    // Draw a circle
    stroke(50);
    fill(50);
    ellipse(x, y, 24, 24);

    // Jiggling randomly on the horizontal axis
    x = x + random(-1, 1);
    // Moving up at a constant speed
    y = y - 1;

    // Reset to the bottom
    if (y < 0) {
        y = height;
    }

//    image(video, 0, 0, width, height);
//        filter(THRESHOLD, 1);


    if (pose) {
        noFill();
        noStroke();

        let d = dist(pose.leftEye.x, pose.leftEye.y, pose.rightEye.x, pose.rightEye.y);

        ellipse(pose.nose.x, pose.nose.y, d * 3);

        let v = createVector(pose.nose.x, pose.nose.y);

        history.push(v);

        let head = history[history.length - 1].copy();
        history.push(head);

        history.shift();


        for (let i = 0; i < history.length - 1; i++) {

            drawHeadSpace(history[i].x, history[i].y);

        }


        for (let i = 0; i < pose.keypoints.length; i++) {
            let x = pose.keypoints[i].position.x;
            let y = pose.keypoints[i].position.y;


            for (let i = 0; i < skeleton.length; i++) {
                let a = skeleton[i][0];
                let b = skeleton[i][1];
                strokeWeight(0);

            }
        }
    }


}

function drawHeadSpace(x, y) {

    fill(0, 0, 255);
    rect(x, y, 30, 30);

    fill(250, 0, 255);
    rect(x - 5, y - 5, 30, 30);

    if (history.length > 20) {
        console.log("more than 20");
        history.splice(100, 1);
    }
}
