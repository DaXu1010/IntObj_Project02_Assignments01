let video;
let poseNet;
let poses = [];



var myRec = new p5.SpeechRec(); // new P5.SpeechRec object



var myVoice = new p5.Speech();
var menuLoaded = 0;
var label, input, checkbox, speakbutton, vslider, rslider, pslider;

function setup() {
    createCanvas(800, 400);
    background(255, 255, 255);
    fill(0, 0, 0, 255);

    video = createCapture(VIDEO);
    video.size(width, height);


    poseNet = ml5.poseNet(video, {
        outputStride: 8,
        quantBytes: 4
    }, modelReady);

    poseNet.on('pose', function (results) {
        poses = results;
    });

    video.hide();




    ///////////////////////////////////////////////////////////////



    // instructions:
    //    textSize(32);
    //    textAlign(CENTER);
    //    fill(255)
    //    text("say something", width / 2, height / 2);

    myRec.onResult = showResult;
    myRec.start();


    speakbutton = createButton('Speak');
    speakbutton.position(20, 500);
    speakbutton.mousePressed(doSpeak);





    // sliders:
    vslider = createSlider(0., 100., 100.);
    vslider.position(20, 540);
    vslider.mouseReleased(setVolume);
    rslider = createSlider(10., 200., 100.);
    rslider.position(20, 560);
    rslider.mouseReleased(setRate);
    pslider = createSlider(1., 200., 100.);
    pslider.position(20, 580);
    pslider.mouseReleased(setPitch);
    // labels:
    label = createDiv("volume");
    label.position(160, 540);
    label = createDiv("rate");
    label.position(160, 560);
    label = createDiv("pitch");
    label.position(160, 580);



}

function modelReady() {
    select('#status').html('Model Loaded');
}

function mousePressed() {
    console.log(JSON.stringify(poses))
}

function draw() {
    image(video, 0, 0, width, height);
    strokeWeight(2);
    //    filter(THRESHOLD, 0.5);

    textSize(32);
    textAlign(CENTER);
    fill(255)
    text("say something", width / 2, 350);



    if (poses.length > 0) {
        const pose = poses[0].pose;
        console.log(pose);


        const nose = pose.nose;
        fill(255, 192, 200);
        text(myRec.resultString, nose.x, nose.y);


    }
}


function showResult() {

}




function setVolume() {
    myVoice.setVolume(vslider.value() / 100.);
}

function setRate() {
    myVoice.setRate(rslider.value() / 100.);
}

function setPitch() {
    myVoice.setPitch(pslider.value() / 100.);
}

function doSpeak() {

    myVoice.speak(myRec.resultString); // debug printer for voice options
}
